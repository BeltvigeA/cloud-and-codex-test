from dataclasses import dataclass
from typing import Dict, Any, Tuple, List, Optional
import cv2
import numpy as np
from skimage.metrics import structural_similarity as ssim


@dataclass
class AnalysisResult:
    verdict: str
    ssim_score: float
    change_area_ratio: float
    thresholds: Dict[str, float]
    align: Dict[str, Any]
    selected_ref: Optional[str] = None
    candidates: Optional[List[Dict[str, Any]]] = None


class BedClearAnalyzer:
    def __init__(
        self,
        ssim_min: float = 0.92,
        change_area_max: float = 0.005,
        gaussian_kernel: Tuple[int, int] = (5, 5),
        orb_features: int = 1000,
        shortlist_k: int = 6,
        dhash_size: int = 8,
        rank_alpha: float = 0.5,
    ) -> None:
        self.ssim_min = float(ssim_min)
        self.change_area_max = float(change_area_max)
        self.gaussian_kernel = gaussian_kernel
        self.orb = cv2.ORB_create(orb_features)
        self.matcher = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=False)
        self.shortlist_k = int(shortlist_k)
        self.dhash_size = int(dhash_size)
        self.rank_alpha = float(rank_alpha)

    def analyze(self, ref_path: str, img_path: str) -> AnalysisResult:
        ref_bgr = self._imread_color(ref_path)
        img_bgr = self._imread_color(img_path)
        aligned_bgr, align_info = self._align_to_ref(ref_bgr, img_bgr)
        verdict, ssim_score, change_ratio = self._compare_core(ref_bgr, aligned_bgr)
        return AnalysisResult(
            verdict=verdict,
            ssim_score=float(ssim_score),
            change_area_ratio=float(change_ratio),
            thresholds={"ssim_min": self.ssim_min, "change_area_max": self.change_area_max},
            align=align_info,
            selected_ref=ref_path,
        )

    def analyze_with_auto_reference(self, ref_paths: List[str], img_path: str) -> AnalysisResult:
        if not ref_paths:
            raise ValueError("ref_paths is empty")
        if len(ref_paths) > 40:
            ref_paths = ref_paths[:40]

        test_bgr = self._imread_color(img_path)
        test_gray = cv2.cvtColor(test_bgr, cv2.COLOR_BGR2GRAY)
        test_hash = self._dhash(test_gray, self.dhash_size)

        hash_scores = []
        for rp in ref_paths:
            rbgr = self._imread_color(rp)
            rgray = cv2.cvtColor(rbgr, cv2.COLOR_BGR2GRAY)
            rhash = self._dhash(rgray, self.dhash_size)
            dist = self._dhash_distance(test_hash, rhash)
            hash_scores.append((rp, dist))
        hash_scores.sort(key=lambda x: x[1])
        shortlist = [rp for rp, _ in hash_scores[: max(1, self.shortlist_k)]]

        scored: List[Dict[str, Any]] = []
        for rp in shortlist:
            rbgr = self._imread_color(rp)
            aligned_bgr, align_info = self._align_to_ref(rbgr, test_bgr)
            verdict, ssim_score, change_ratio = self._compare_core(rbgr, aligned_bgr)
            score = float(ssim_score) - self.rank_alpha * float(change_ratio)
            scored.append({
                "ref": rp,
                "ssim": float(ssim_score),
                "change_area_ratio": float(change_ratio),
                "rank_score": float(score),
                "align": align_info,
                "verdict": verdict,
            })
        scored.sort(key=lambda d: d["rank_score"], reverse=True)
        best = scored[0]

        return AnalysisResult(
            verdict=best["verdict"],
            ssim_score=best["ssim"],
            change_area_ratio=best["change_area_ratio"],
            thresholds={"ssim_min": self.ssim_min, "change_area_max": self.change_area_max},
            align=best["align"],
            selected_ref=best["ref"],
            candidates=scored,
        )

    def _compare_core(self, ref_bgr: np.ndarray, aligned_bgr: np.ndarray):
        ref_gray = cv2.cvtColor(ref_bgr, cv2.COLOR_BGR2GRAY)
        img_gray = cv2.cvtColor(aligned_bgr, cv2.COLOR_BGR2GRAY)

        ref_blur = cv2.GaussianBlur(ref_gray, self.gaussian_kernel, 0)
        img_blur = cv2.GaussianBlur(img_gray, self.gaussian_kernel, 0)

        ssim_score, _ = ssim(ref_blur, img_blur, full=True, data_range=255)

        absd = cv2.absdiff(ref_blur, img_blur)
        _, th = cv2.threshold(absd, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        th = self._morph_open_close(th, k_open=3, k_close=5)
        change_ratio = float(np.count_nonzero(th)) / float(th.size)

        if ssim_score >= self.ssim_min and change_ratio <= self.change_area_max:
            verdict = "clear"
        elif ssim_score < (self.ssim_min * 0.85) or change_ratio > (self.change_area_max * 2.0):
            verdict = "occupied"
        else:
            verdict = "inconclusive"

        return verdict, float(ssim_score), float(change_ratio)

    def _align_to_ref(self, ref_bgr: np.ndarray, img_bgr: np.ndarray):
        h, w = ref_bgr.shape[:2]
        info = {"matches": 0, "inliers": 0, "homography_ok": False, "width": int(w), "height": int(h)}

        ref_gray = cv2.cvtColor(ref_bgr, cv2.COLOR_BGR2GRAY)
        img_gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)

        kp1, des1 = self.orb.detectAndCompute(ref_gray, None)
        kp2, des2 = self.orb.detectAndCompute(img_gray, None)

        if des1 is None or des2 is None or len(kp1) < 10 or len(kp2) < 10:
            resized = cv2.resize(img_bgr, (w, h), interpolation=cv2.INTER_LINEAR)
            return resized, info

        knn = self.matcher.knnMatch(des1, des2, k=2)
        good = []
        for m_n in knn:
            if len(m_n) < 2:
                continue
            m, n = m_n
            if m.distance < 0.75 * n.distance:
                good.append(m)
        info["matches"] = int(len(knn))

        if len(good) < 8:
            resized = cv2.resize(img_bgr, (w, h), interpolation=cv2.INTER_LINEAR)
            return resized, info

        src_pts = np.float32([kp1[m.queryIdx].pt for m in good]).reshape(-1, 1, 2)
        dst_pts = np.float32([kp2[m.trainIdx].pt for m in good]).reshape(-1, 1, 2)

        H, mask = cv2.findHomography(dst_pts, src_pts, cv2.RANSAC, 5.0)
        if H is None:
            resized = cv2.resize(img_bgr, (w, h), interpolation=cv2.INTER_LINEAR)
            return resized, info

        info["homography_ok"] = True
        info["inliers"] = int(mask.sum()) if mask is not None else 0
        warped = cv2.warpPerspective(img_bgr, H, (w, h), flags=cv2.INTER_LINEAR)
        return warped, info

    def _dhash(self, gray: np.ndarray, hash_size: int = 8) -> np.ndarray:
        small = cv2.resize(gray, (hash_size + 1, hash_size), interpolation=cv2.INTER_AREA)
        diff = small[:, 1:] > small[:, :-1]
        return diff

    @staticmethod
    def _dhash_distance(h1: np.ndarray, h2: np.ndarray) -> int:
        if h1.shape != h2.shape:
            raise ValueError("dhash shapes differ")
        return int(np.count_nonzero(h1 != h2))

    @staticmethod
    def _imread_color(path: str) -> np.ndarray:
        img = cv2.imread(path, cv2.IMREAD_COLOR)
        if img is None:
            raise FileNotFoundError(f"Could not read image: {path}")
        return img

    @staticmethod
    def _morph_open_close(binary: np.ndarray, k_open: int = 3, k_close: int = 5) -> np.ndarray:
        ko = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k_open, k_open))
        kc = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k_close, k_close))
        x = cv2.morphologyEx(binary, cv2.MORPH_OPEN, ko)
        x = cv2.morphologyEx(x, cv2.MORPH_CLOSE, kc)
        return x
