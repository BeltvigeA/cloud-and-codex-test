from __future__ import annotations
import os
import json
import uuid
import shutil
from pathlib import Path
from datetime import datetime
from typing import List

from flask import Flask, render_template, request, redirect, url_for, send_file, flash, abort
from werkzeug.utils import secure_filename

from analyzer import BedClearAnalyzer

ALLOWED_EXTS = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"}
MAX_REFS = 40
IMG_TEST = "img.jpg"

app = Flask(__name__)
app.secret_key = os.environ.get("BEDCHECK_GUI_SECRET", "dev-secret")

WORK_ROOT = Path.cwd() / "sessions"
WORK_ROOT.mkdir(parents=True, exist_ok=True)

def _assert_allowed(filename: str) -> None:
    ext = Path(filename).suffix.lower()
    if ext not in ALLOWED_EXTS:
        raise ValueError(f"Filetype ikke tillatt: {ext}")

def _new_session_dir() -> Path:
    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    sid = f"{ts}-{uuid.uuid4().hex[:8]}"
    d = WORK_ROOT / sid
    d.mkdir(parents=True, exist_ok=True)
    return d

def _save_uploaded(file_storage, target_dir: Path, target_name: str) -> Path:
    _ = secure_filename(file_storage.filename or target_name)
    target = target_dir / target_name
    file_storage.save(str(target))
    return target

@app.route("/", methods=["GET"])
def index():
    return render_template("index.html")

@app.route("/analyze", methods=["POST"])
def analyze():
    ref_files = request.files.getlist("refs")
    img = request.files.get("img")

    if not ref_files or not img:
        flash("Du må velge minst 1 referansebilde (helst flere) og 1 testbilde.")
        return redirect(url_for("index"))

    _assert_allowed(img.filename)
    for rf in ref_files:
        _assert_allowed(rf.filename)

    work = _new_session_dir()
    refs_dir = work / "refs"
    refs_dir.mkdir(parents=True, exist_ok=True)

    ref_paths: List[str] = []
    for i, rf in enumerate(ref_files[:MAX_REFS], start=1):
        name = f"ref_{i:02d}.jpg"
        ref_paths.append(str(_save_uploaded(rf, refs_dir, name)))

    img_path = _save_uploaded(img, work, IMG_TEST)

    analyzer = BedClearAnalyzer()
    res = analyzer.analyze_with_auto_reference(ref_paths, str(img_path))
    payload = {
        "verdict": res.verdict,
        "ssim": round(res.ssim_score, 6),
        "change_area_ratio": round(res.change_area_ratio, 6),
        "thresholds": res.thresholds,
        "align": res.align,
        "selected_ref": res.selected_ref,
        "candidates": res.candidates,
    }
    (work / "result.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")

    ref_best = None
    if res.selected_ref:
        ref_best = work / "ref_best.jpg"
        shutil.copy2(res.selected_ref, ref_best)

    _zip_directory(work)

    return render_template(
        "index.html",
        result=payload,
        work_id=work.name,
        download_result_url=url_for("download_result_zip", work_id=work.name),
        preview_selected_ref_url=url_for("preview_file", work_id=work.name, fname="ref_best.jpg") if ref_best else None,
        preview_test_url=url_for("preview_file", work_id=work.name, fname=IMG_TEST),
    )

def _zip_directory(dir_path: Path) -> Path:
    base = str(dir_path)
    root, name = os.path.split(base)
    archive_base = os.path.join(root, name)
    zip_full = Path(archive_base + ".zip")
    if zip_full.exists():
        zip_full.unlink()
    shutil.make_archive(archive_base, "zip", root_dir=root, base_dir=name)
    return zip_full

@app.route("/preview/<work_id>/<fname>", methods=["GET"])
def preview_file(work_id: str, fname: str):
    work = WORK_ROOT / work_id
    target = work / fname
    if not target.exists():
        target = work / "refs" / fname
        if not target.exists():
            abort(404)
    return send_file(str(target), conditional=True, max_age=0)

@app.route("/download/result/<work_id>", methods=["GET"])
def download_result_zip(work_id: str):
    work = WORK_ROOT / work_id
    if not work.is_dir():
        abort(404)
    zip_path = work.with_suffix(".zip")
    if not zip_path.exists():
        zip_path = _zip_directory(work)
    return send_file(
        str(zip_path),
        as_attachment=True,
        download_name=f"{work_id}.zip",
        mimetype="application/zip",
        max_age=0,
    )

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
