# BedCheck Pro (multi-referanse, lokal)

Prod-klar GUI som støtter **opptil 40 referansebilder** i ulike Z-høyder og velger automatisk nærmeste match før analyse.

## Kjappstart
```bash
pip install -r requirements.txt
python app.py
# Åpne http://127.0.0.1:5000
```

## Hva er nytt
- Multi-referansevalg med **dHash-shortlist** → **ORB+RANSAC** → **SSIM/Change** rangering.
- Forhåndsvisning av **valgt referanse** + **testbilde** side-om-side.
- ZIP av hele sesjonen (inndata + `result.json`).

## Struktur
```
bedcheck_gui_pro/
  app.py
  analyzer.py
  templates/
    index.html
  requirements.txt
  README.md
  sessions/   # autogenerert ved kjøring
```

## Notater
- Bruk rene, skarpe referansebilder med samme kamera/lys.
- Juster terskler i `analyzer.py` (`ssim_min`, `change_area_max`) om nødvendig.
